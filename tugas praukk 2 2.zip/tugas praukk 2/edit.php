<?php session_start(); ?>

<?php
if (!isset($_SESSION['valid'])) {
	header('Location: login.php');
}
?>

<?php
include_once("connection.php");

if (isset($_POST['update'])) {
	$id = $_POST['id'];

	$name = $_POST['name'];
	$category = $_POST['category'];
	$country = $_POST['country'];
	$price = $_POST['price'];

	if (empty($name) || empty($category) || empty($country) || empty($price)) {

		if (empty($name)) {
			echo "<font color='red'>Name field is empty.</font><br/>";
		}

		if (empty($category)) {
			echo "<font color='red'>Category field is empty.</font><br/>";
		}

		if (empty($country)) {
			echo "<font color='red'>Country field is empty.</font><br/>";
		}
		if (empty($price)) {
			echo "<font color='red'>Price field is empty.</font><br/>";
		}
	} else {
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE food SET name='$name', category='$category', country='$country', price='$price' WHERE id=$id");

		//redirectig to the display page. In our case, it is view.php
		header("Location: view.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM food WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
	$name = $res['name'];
	$address = $res['category'];
	$religion = $res['country'];
	$class = $res['price'];
}
?>
<html>

<head>
	<title>Edit Data</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
		integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
		<link rel="stylesheet" href="style.css">
		<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');
</style>
</head>

<body>
	<div class="card">
<nav class="navbar navbar-expand-lg bg-info-subtle ">
  <div class="container-fluid">
    <a class="nav-link" href="index.php"> Home </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse  " id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" aria-current="page" href="view.php">  View Students </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
        </li>
      </ul>
    </div>
  </div>
</nav>
	<form name="form1" method="post" action="edit.php">
		<table border="0">
			<tr>

				<div class="input-group mb-3">
					<td>Name</td>
					<td><input class="form-control" type="text" name="name" value="<?php echo $name; ?>"></td>
				</div>
			</tr>
			<tr>
				<td>Category</td>
				<td><input class="form-control" type="text" name="category" value="<?php echo $category; ?>"></td>
			</tr>
			<tr>
				<td>Country</td>
				<td><input class="form-control" type="text" name="country" value="<?php echo $country; ?>"></td>
			</tr>
			<tr>
				<td>Price</td>
				<td><input class="form-control" type="text" name="price" value="<?php echo $price; ?>"></td>
			</tr>

			<tr>

			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id']; ?>></td>
				<td><input class="btn btn-outline-danger me-2" type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

</body>

</html>